try:
    from .socx import main
except:
    from socx import main
